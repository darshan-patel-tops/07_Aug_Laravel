<?php




class model 
{
    public $connection;

    
    public function register($data)
    {
        //
        
    }
    
}

?>